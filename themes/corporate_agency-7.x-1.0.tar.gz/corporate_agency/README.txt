About Corporate Agency
====================
Corporate Agency is a Drupal 7 theme. The theme is not dependent on any 
core theme. Its very light weight for fast loading with modern look.
  Simple and clean design
  Drupal standards compliant
  Implementation of a JS Slideshow
  Multi-level drop-down menus
  Footer with 4 regions
  A total of 10 regions
  Compatible and tested on IE7, IE8, IE9+, Opera, Firefox, Chrome browsers

Browser compatibility:
=====================
The theme has been tested on following browsers. IE7+, Firefox, Google Chrome, Opera.

Drupal compatibility:
=====================
This theme is compatible with Drupal 7.x.x

Developed by
============
www.devsaran.com


Help and Support Us
=====================
Please consider a small donation 
Paypal ID : donation@devsaran.com